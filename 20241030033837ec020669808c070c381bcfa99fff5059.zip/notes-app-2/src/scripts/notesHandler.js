const ENDPOINT = "https://notes-api.dicoding.dev/v2";


const getNotes = async (callback) => {
    try {
        
        const response = await fetch(`${ENDPOINT}/notes`);
        const result = await response.json();
        return result.data;
    } catch (error) {
        console.log(error)
    } finally{
        callback();
    }
}

const addNotes = async (newNote) => {
    try {
        await fetch(`${ENDPOINT}/notes`, {
            method: "POST",
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(newNote)
        });
    } catch (error) {
        console.log(error)
    }
}

const deleteNotes = async (id) => {
    try {
        await fetch(`${ENDPOINT}/notes/${id}`, {
            method: "DELETE",
            headers: {
                'Content-Type': 'application/json'
            },
        });
    } catch (error) {
        console.log(error)
    }

}

export { getNotes, addNotes, deleteNotes };