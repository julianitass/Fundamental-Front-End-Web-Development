import { deleteNotes } from "../notesHandler";

// Membuat custom element untuk catatan individual
class NoteItem extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({ mode: 'open' });
    }
  
    connectedCallback() {
        const noteTitle = this.getAttribute('title');
        const noteBody = this.getAttribute('body');
        const noteCreatedAt = this.getAttribute('createdAt');
        const noteId = this.getAttribute('id');
  
        this.shadowRoot.innerHTML = `
            <style>
                .note {
                    border: 1px solid #ddd;
                    border-radius: 5px;
                    padding: 15px;
                    margin: 10px 0;
                    background-color: #fafafa;
                }
                .note h2 {
                    margin: 0 0 10px;
                    font-size: 18px;
                    color: #007BFF;
                }
                .note p {
                    margin: 5px 0;
                }
                .note small {
                    color: #777;
                }
                .delete-button {
                    background-color: red;
                    color: white;
                    border: none;
                    padding: 5px 10px;
                    border-radius: 4px;
                    cursor: pointer;
                    float: right;
                }
                .delete-button:hover {
                    background-color: darkred;
                }
            </style>
            <div class="note">
                <h2>${noteTitle}</h2>
                <button class="delete-button" data-id="${noteId}">Hapus</button>
                <p>${noteBody.replace(/\n/g, '<br>')}</p>
                <p><small>Dibuat pada: ${new Date(noteCreatedAt).toLocaleString()}</small></p>
            </div>
        `;
  
        this.shadowRoot.querySelector('.delete-button').addEventListener('click', async () => {
            const id = this.getAttribute('id');
            await deleteNotes(id);
            document.dispatchEvent(new CustomEvent('note-deleted'));
        });
    }
  }
  
  // Daftarkan custom element untuk catatan
  customElements.define('note-item', NoteItem);