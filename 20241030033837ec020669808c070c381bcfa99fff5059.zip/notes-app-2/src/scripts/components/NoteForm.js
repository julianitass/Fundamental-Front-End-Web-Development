import notesData from "../notes";
import { addNotes,getNotes } from "../notesHandler";

// Membuat custom element untuk form catatan
class NoteForm extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({ mode: 'open' });
    }
  
    connectedCallback() {
        this.shadowRoot.innerHTML = `
            <style>
                form {
                    margin-bottom: 20px;
                }
                input[type="text"],
                textarea {
                    width: 100%;
                    padding: 10px;
                    margin: 5px 0;
                    border: 1px solid #ddd;
                    border-radius: 4px;
                }
                button {
                    background-color: #007BFF;
                    color: white;
                    border: none;
                    padding: 10px;
                    border-radius: 4px;
                    cursor: pointer;
                }
                button:hover {
                    background-color: #0056b3;
                }
            </style>
            <form id="noteForm">
                <input type="text" id="noteTitle" placeholder="Judul Catatan" required>
                <textarea id="noteBody" placeholder="Isi Catatan" required></textarea>
                <button type="submit">Tambah Catatan</button>
            </form>
        `;
  
        this.shadowRoot.getElementById('noteForm').addEventListener('submit', (event) => {
            event.preventDefault();
  
            const title = this.shadowRoot.getElementById('noteTitle').value;
            const body = this.shadowRoot.getElementById('noteBody').value;
  
            const newNote = {
                // id: `notes-${Date.now()}`,
                title: title,
                body: body,
                // createdAt: new Date().toISOString(),
                // archived: false,
            };
  
            // Push the new note to notesData
            // notesData.push(newNote);
            addNotes(newNote);

            // Dispatch event to notify that a note has been added
            document.dispatchEvent(new CustomEvent('note-added', { detail: newNote }));
  
            // Clear the form fields
            this.shadowRoot.getElementById('noteTitle').value = '';
            this.shadowRoot.getElementById('noteBody').value = '';
        });
    }
   
  }
// Daftarkan custom element untuk form
customElements.define('note-form', NoteForm);