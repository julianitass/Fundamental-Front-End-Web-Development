import notesData from "../notes";
import { getNotes } from "../notesHandler";

// Membuat custom element untuk daftar catatan
class NoteList extends HTMLElement {
    constructor() {
        super();
        this.attachShadow({ mode: 'open' });
    }
  
    connectedCallback() {
        this.render();
        // document.addEventListener('note-added', () => this.render());
        document.addEventListener('note-added', () => this.showNotes());
        document.addEventListener('note-deleted', () => this.showNotes());
        // document.addEventListener('note-deleted', (event) => {
        //     const id = event.detail;
        //     notesData = notesData.filter(note => note.id !== id);
        //     this.render();
        // });
    }
  
    render() {
        this.shadowRoot.innerHTML = `
            <style>
                #notesContainer {
                    display: none;
                    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
                    gap: 20px;
                }
                svg {
                width: 3.25em;
                transform-origin: center;
                animation: rotate4 2s linear infinite;
                }
                circle {
                fill: none;
                stroke: hsl(214, 97%, 59%);
                stroke-width: 2;
                stroke-dasharray: 1, 200;
                stroke-dashoffset: 0;
                stroke-linecap: round;
                animation: dash4 1.5s ease-in-out infinite;
                }
                @keyframes rotate4 {
                100% {
                transform: rotate(360deg);
                }
                }

                @keyframes dash4 {
                0% {
                stroke-dasharray: 1, 200;
                stroke-dashoffset: 0;
                }

                50% {
                stroke-dasharray: 90, 200;
                stroke-dashoffset: -35px;
                }

                100% {
                stroke-dashoffset: -125px;
                }
                }
                #loading-indicator {
                display:flex;
                justify-content:center;
                }
                </style>
                <div id="loading-indicator">
                    <svg viewBox="25 25 50 50">
                        <circle r="20" cy="50" cx="50"></circle>
                    </svg>
                </div>
                <div id="notesContainer"></div>
            `;
  
        this.showNotes();
       
    }
    async showNotes(){
        const loadingIndicator = this.shadowRoot.getElementById('loading-indicator');
        const notesContainer = this.shadowRoot.getElementById('notesContainer');
        notesContainer.style.display = "none";
        loadingIndicator.style.display = "flex";
        notesContainer.innerHTML = '';
        const notes = await getNotes(()=>{
            setTimeout(() => {
                notesContainer.style.display = "grid";
                loadingIndicator.style.display = "none";
            }, 500);
        });
         // Sort notes by creation date
         const sortedNotes = notes.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
         sortedNotes.forEach(note => {
             const noteItem = document.createElement('note-item');
             noteItem.setAttribute('title', note.title);
             noteItem.setAttribute('body', note.body);
             noteItem.setAttribute('createdAt', note.createdAt);
             noteItem.setAttribute('id', note.id);
             notesContainer.appendChild(noteItem);
         });
        console.log(notes);
    }
  }
  
  // Daftarkan custom element untuk daftar catatan
  customElements.define('note-list', NoteList);