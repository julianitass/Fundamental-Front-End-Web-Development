import "../styles/styles.css";
import "./components/NoteForm";
import "./components/NoteItem";
import "./components/NoteList";

// Panggil fungsi untuk menampilkan daftar catatan setelah DOM siap
document.addEventListener('DOMContentLoaded', () => {
  const noteForm = document.createElement('note-form');
  const noteList = document.createElement('note-list');
  document.body.appendChild(noteForm);
  document.body.appendChild(noteList);
});

